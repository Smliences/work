/*
SQLyog Ultimate v12.09 (64 bit)
MySQL - 5.5.28 : Database - bbs
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`bbs` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `bbs`;

/*Table structure for table `question` */

DROP TABLE IF EXISTS `question`;

CREATE TABLE `question` (
  `qid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `title` varchar(60) NOT NULL,
  `content` longtext NOT NULL,
  `wtime` varchar(60) NOT NULL,
  PRIMARY KEY (`qid`),
  KEY `FK9sgnhx4p76r4hka76ebi3khgw` (`uid`),
  CONSTRAINT `FK9sgnhx4p76r4hka76ebi3khgw` FOREIGN KEY (`uid`) REFERENCES `user` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `question` */

/*Table structure for table `reply` */

DROP TABLE IF EXISTS `reply`;

CREATE TABLE `reply` (
  `rid` int(11) NOT NULL AUTO_INCREMENT,
  `fromuser` int(11) NOT NULL,
  `qid` int(11) NOT NULL,
  `touser` int(11) DEFAULT NULL,
  `content` varchar(60) NOT NULL,
  `rtime` varchar(60) NOT NULL,
  PRIMARY KEY (`rid`),
  KEY `FK9hax8vj3p8ldsc1vuyg6eb1ho` (`fromuser`),
  KEY `FKc4jp5uacr55j2fulkwtme2y8f` (`qid`),
  CONSTRAINT `FK9hax8vj3p8ldsc1vuyg6eb1ho` FOREIGN KEY (`fromuser`) REFERENCES `user` (`uid`),
  CONSTRAINT `FKc4jp5uacr55j2fulkwtme2y8f` FOREIGN KEY (`qid`) REFERENCES `question` (`qid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `reply` */

/*Table structure for table `t_user` */

DROP TABLE IF EXISTS `t_user`;

CREATE TABLE `t_user` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `t_user` */

insert  into `t_user`(`user_id`,`user_name`) values (1,'zhangsan');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pwd` varchar(20) NOT NULL,
  `name` varchar(10) NOT NULL,
  `num` varchar(11) NOT NULL,
  `role` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

/*Data for the table `user` */

insert  into `user`(`uid`,`pwd`,`name`,`num`,`role`) values (1,'1','1','1','1'),(5,'123','123','178','版主');

/* Trigger structure for table `user` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `insert_check` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'localhost' */ /*!50003 TRIGGER `insert_check` AFTER INSERT ON `user` FOR EACH ROW BEGIN
	insert into t_user values(new.name);
    END */$$


DELIMITER ;

/* Procedure structure for procedure `findById` */

/*!50003 DROP PROCEDURE IF EXISTS  `findById` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `findById`(in uid int)
BEGIN
	select * from user where uid = uid;
    END */$$
DELIMITER ;

/* Procedure structure for procedure `findQuestionById` */

/*!50003 DROP PROCEDURE IF EXISTS  `findQuestionById` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `findQuestionById`(in qid int)
BEGIN
	select * from question where qid = qid;
    END */$$
DELIMITER ;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
