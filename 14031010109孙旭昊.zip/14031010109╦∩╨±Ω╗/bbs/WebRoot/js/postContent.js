var huifu = document.getElementById("huifu");
var huifuContent = document.getElementById("huifuContent");
var huifuSubmit = document.getElementById("huifuSubmit");

huifu.onclick = function() {
	huifuContent.style.display = 'block';
	huifuSubmit.style.display = 'block';
}