package cn.edu.rjxy.dao;

import java.sql.SQLException;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import cn.edu.rjxy.bean.User;
import cn.edu.rjxy.utils.JDBCUtils;

public class UserDao {
	
	/**/
	private QueryRunner qr = new QueryRunner(JDBCUtils.getDataSource());
	
	/*添加用户*/
	public void insert(User user) throws SQLException{
		String sql = "insert into user values(?,?,?,?,?)";
		qr.update(sql, user.getId(),user.getUsername(),user.getPassword(),user.getName(),user.getTelephone());
		
	}
	
	/*根据查询username返回信息*/
	public User findByUsername(String username) throws SQLException{
		String sql = "select * from user where username=?";
		User user = qr.query(sql, new BeanHandler<User>(User.class), username);
		return user;
	}
	
	/*修改个人信息*/
	public void update(User user) throws SQLException{
		String sql = "update user set password=?,telephone=? where id=? ";
		qr.update(sql, user.getPassword(),user.getTelephone(),user.getId());
		
	}
	
	/*个人信息修改过后，重新查询信息，并返回页面*/
	public User flushById(String id) throws SQLException{
		String sql = "select * from user where id=?";
		User user = qr.query(sql, new BeanHandler<User>(User.class),id);
		System.out.println(user.getId());
		System.out.println(user.getName());
		System.out.println(user.getPassword());
		System.out.println(user.getTelephone());
		System.out.println(user.getUsername());
		return user;
	}
}
