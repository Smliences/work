package cn.edu.rjxy.dao;

/*Calibri 字体*/
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import cn.edu.rjxy.bean.OrderItem;
import cn.edu.rjxy.bean.Product;
import cn.edu.rjxy.utils.JDBCUtils;

public class OrderItemDao {
	private QueryRunner qr  = new QueryRunner(JDBCUtils.getDataSource());
	
	//添加订单项到数据库表orderitem中
	public void addItem(OrderItem orderItem) throws SQLException{
		Connection conn = JDBCUtils.getConnection();
		String sql = "insert into orderitem values(?,?,?,?,?)";
		qr.update(conn, sql, orderItem.getId(),orderItem.getOrder_id()
				,orderItem.getProduct_id(),orderItem.getBuynum(),orderItem.getSubtotal());
		
		
	}
	
	//查看订单详情（商品名，价格 ，购买数量，小计）
	public List<OrderItem> findOrderItem(String order_id) throws SQLException{
		/*1、查询某个订单所包含的所有订单项*/
		String sql = "select * from orderitem where order_id =?";
		List<OrderItem> orderItemList = qr.query(sql, 
				new BeanListHandler<OrderItem>(OrderItem.class), order_id);
		
		/*2、查询出某个订单所包含的订单项对应的商品(并列查询)*/
		sql = "select p.id,p.name,p.price from product p, orderitem oi where p.id=oi.product_id and order_id=?";
		List<Product> productList = qr.query(sql, new BeanListHandler<Product>(Product.class), order_id);
		
		/*3、给每个订单项添加商品属性*/
		for(OrderItem oi:orderItemList){
			for(Product p:productList){
				oi.setProduct(p);
			}
		}
		
		return orderItemList;
		
	}
	
	
	
}
