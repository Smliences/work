package cn.edu.rjxy.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import cn.edu.rjxy.bean.Product;
import cn.edu.rjxy.utils.JDBCUtils;

public class ProductDao {
	private QueryRunner qr = new QueryRunner(JDBCUtils.getDataSource());
	
	/*查询所有商品*/
	public List<Product> findAll() throws SQLException{
		String sql = "select * from product ";
		List<Product> list = qr.query(sql, new BeanListHandler<Product>(Product.class));
		return list;
	}
	
	/*根据id查询商品*/
	public Product findById(String id) throws SQLException{
		String sql = "select * from product where id=?";
		Product product = qr.query(sql, new BeanHandler<Product>(Product.class), id);
		return product;
	}
	
	/*删除商品*/
	public void deleteProduct(String id) throws SQLException{
		String sql = "delete from product where id=?";
		qr.update(sql, id);
	}
	
	/*修改商品信息*/
	public void updateProduct(Product p) throws SQLException{
		String sql = "update product set name=?,price=?,category=?,pnum=?,imgurl=?,imgurl2=?,description=? where id=?";
		qr.update(sql, p.getName(),p.getPrice(),p.getCategory(),p.getPnum(),p.getImgurl(),p.getImgurl2(),p.getDescription(),p.getId());
		
	}
	
	/*新增商品*/
	public void addProduct(Product p) throws SQLException{
		String sql = "insert into product (id,name,price,category,pnum,imgurl,imgurl2,description)  values(?,?,?,?,?,?,?,?)";
		qr.update(sql, p.getId(),p.getName(),p.getPrice(),p.getCategory(),p.getPnum(),p.getImgurl()
				,p.getImgurl2(),p.getDescription());
	}
	
	
	/*查询记录总条数*/
	public int queryTotalRecord() throws SQLException{
		String sql = "select count(*) from product";
		Long num = qr.query(sql, new ScalarHandler<Long>());
		return num.intValue();
	}
	
	/*分页查询*/
	public List<Product> queryByPage(int recordStartIndex,int pageSize) throws SQLException{
		String sql = "select * from product limit ?,?";
		List<Product> dates = qr.query(sql, 
				new BeanListHandler<Product>(Product.class),recordStartIndex,pageSize);
		return dates;
	}
	
	/*按种类分页查询*/
	public List<Product> queryByPage2(int recordStartIndex,int pageSize,String category) throws SQLException{
		String sql = "select * from product  where category=? limit ?,?";
		List<Product> dates = qr.query(sql, 
				new BeanListHandler<Product>(Product.class),category,recordStartIndex,pageSize);
		
		return dates;
	}
	
	/*按种类查询后，记录的总条数*/
	public int queryCategoryRecord(String category) throws SQLException{
		String sql = "select count(*) from product where category=?";
		Long num = qr.query(sql, new ScalarHandler<Long>(),category);
		
		return num.intValue();
	}
}
