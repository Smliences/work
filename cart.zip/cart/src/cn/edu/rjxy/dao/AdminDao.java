package cn.edu.rjxy.dao;

import java.sql.SQLException;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import cn.edu.rjxy.bean.Admin;
import cn.edu.rjxy.utils.JDBCUtils;

public class AdminDao {
	QueryRunner qr = new QueryRunner(JDBCUtils.getDataSource());

	public Admin FindByUsername(String username) throws SQLException {
		String sql = "select * from admin where username=?";
		Admin admin = qr.query(sql, new BeanHandler<Admin>(Admin.class),
				username);
		return admin;
	}
	
	
	
}
