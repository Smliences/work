package cn.edu.rjxy.service;

import java.sql.SQLException;
import java.util.List;

import cn.edu.rjxy.bean.Order;
import cn.edu.rjxy.bean.OrderItem;
import cn.edu.rjxy.dao.OrderDao;
import cn.edu.rjxy.dao.OrderItemDao;
import cn.edu.rjxy.utils.JDBCUtils;

public class OrderService {
	private OrderDao orderDao = new OrderDao();
	private OrderItemDao orderItemDao = new OrderItemDao();
	
	public String addOrder(Order order){
		try{
			//开启事务
			JDBCUtils.startTransaction();
			//添加订单
			orderDao.addOrder(order);
			//获取订单集合
			List<OrderItem> list = order.getList();
			//遍历订单项目，依次插入orderitem表中
			for(OrderItem orderItem:list){
				orderItemDao.addItem(orderItem);
			}
			//提交事物
			JDBCUtils.commit();
			return "成功";
		}catch(Exception e){
			JDBCUtils.rollback();
			e.printStackTrace();
			return "失败";
		}
	
	}
	
	//查看我的订单
	public List<Order> findMyOrder(String user_id){
		try {
			return orderDao.findOrderByUser_id(user_id);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	//查看订单详情
	public List<OrderItem> findOrderItem(String order_id){
		try {
			return orderItemDao.findOrderItem(order_id);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	
}
