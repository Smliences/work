package cn.edu.rjxy.service;

import java.sql.SQLException;

import cn.edu.rjxy.bean.User;
import cn.edu.rjxy.dao.UserDao;

public class UserService {
	private UserDao dao = new UserDao();
	
	public void register(User user) throws UserException{
		try {
			User u = dao.findByUsername(user.getUsername());
			if(u!=null){
				throw new UserException("用户名已被占用，请换用其他名字");
			}else{
				dao.insert(user);
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	}
	
	public User findByUsername(String username){
		try {
			return dao.findByUsername(username);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public void update(User user){
		try {
			dao.update(user);
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
	
	public User flashById(String id){
		try {
			User user = dao.flushById(id);
			return user;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
		
	}
}
