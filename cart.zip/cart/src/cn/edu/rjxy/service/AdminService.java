package cn.edu.rjxy.service;

import java.sql.SQLException;

import cn.edu.rjxy.bean.Admin;

import cn.edu.rjxy.dao.AdminDao;

public class AdminService {
	private AdminDao dao = new AdminDao();
	public Admin login(Admin admin) throws UserException{
		try {
			Admin ad = dao.FindByUsername( admin.getUsername());
			if(ad==null){
				throw new UserException("用户名不存在");
			}
			if(!ad.getPassword().equals(admin.getPassword())){
				throw new UserException("密码错误");
			}
			return ad;
		} catch (SQLException e) {
			
		throw new RuntimeException();
		}
	}
}
