package cn.edu.rjxy.service;

import java.sql.SQLException;
import java.util.List;

import cn.edu.rjxy.bean.PageBean;
import cn.edu.rjxy.bean.Product;
import cn.edu.rjxy.dao.ProductDao;

public class ProductService {
	private ProductDao productDao = new ProductDao();
	
	/*查询所有商品*/
	public List<Product> findAll(){
		List<Product> list;
		try {
			list = productDao.findAll();
			return list;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
		
	}
	
	/*根据ID查询商品*/
	public Product findById(String id){
		try {
			Product product = productDao.findById(id);
			return product;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
		
	}
	
	/*删除商品*/
	public void deleteProduct(String id){
		try {
			productDao.deleteProduct(id);
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	}
	/*修改商品信息*/
	public void updateProduct(Product p){
		try {
			productDao.updateProduct(p);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	/*新增商品*/
	public void addProduct(Product p){
		try {
			productDao.addProduct(p);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/*全部商品， 分页查询*/
	public PageBean queryByPage(int pageCode){
		
		try {
			//获取总记录数
			int  totalRecord = productDao.queryTotalRecord();
			//创建PageBean
			PageBean pb = new PageBean(pageCode, totalRecord);
			//查询当前页的记录
			List<Product> datas = productDao.queryByPage((pageCode-1)*pb.getPageSize(), pb.getPageSize());
			//将datas封装到pb
			pb.setDatas(datas);
			return pb;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}


	/*分种类后，分页查询*/
	public PageBean queryByCategory(int pageCode,String category){
		
		try {
			//根据种类的关键词，从数据库中获取记录数
			int  totalRecord = productDao.queryCategoryRecord(category);
			//创建PageBean
			PageBean pb = new PageBean(pageCode, totalRecord);
			//查询当前页的记录
			List<Product> datas = productDao.queryByPage2((pageCode-1)*pb.getPageSize(), pb.getPageSize(),category);
			//将datas封装到pb
			pb.setDatas(datas);
			return pb;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
}
