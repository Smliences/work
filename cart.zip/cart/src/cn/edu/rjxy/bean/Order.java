package cn.edu.rjxy.bean;

import java.util.Date;
import java.util.List;
/*订单*/
public class Order {
	/*
	 * 订单包含：
	 * 
	 * 订单的ID
	 * 订单总金额
	 * 收货人地址
	 * 收货人姓名
	 * 收货人电话
	 * 订单状态
	 * 生成订单时间
	 * 购买人的ID
	 * （多个）订单项
	 * */
	private String id;
	private double totalmoney;
	private String receiverAddress;
	private String receiverName;
	private String receiverPhone;
	/*订单状态    0：未付款    1 ： 已付款   */
	private int paystate;
	/*生成订单时间*/
	private Date ordertime;
	private String user_id;
	/*一个订单中包含若干订单项*/
	private List<OrderItem> list;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public double getTotalmoney() {
		return totalmoney;
	}
	public void setTotalmoney(double totalmoney) {
		this.totalmoney = totalmoney;
	}
	public String getReceiverAddress() {
		return receiverAddress;
	}
	public void setReceiverAddress(String receiverAddress) {
		this.receiverAddress = receiverAddress;
	}
	public String getReceiverName() {
		return receiverName;
	}
	public void setReceiverName(String receiverName) {
		this.receiverName = receiverName;
	}
	public String getReceiverPhone() {
		return receiverPhone;
	}
	public void setReceiverPhone(String receiverPhone) {
		this.receiverPhone = receiverPhone;
	}
	public int getPaystate() {
		return paystate;
	}
	public void setPaystate(int paystate) {
		this.paystate = paystate;
	}
	public Date getOrdertime() {
		return ordertime;
	}
	public void setOrdertime(Date ordertime) {
		this.ordertime = ordertime;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public List<OrderItem> getList() {
		return list;
	}
	public void setList(List<OrderItem> list) {
		this.list = list;
	}
	
	
	
	
	
	
}
