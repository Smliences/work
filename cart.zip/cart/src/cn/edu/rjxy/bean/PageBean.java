package cn.edu.rjxy.bean;

import java.util.List;

//封装分页相关数据
public class PageBean {
	private int  pageCode;//当前页码
	
	//product中记录的条数
	private  List<Product> datas;
	private int totalRecord;//总记录数
	private int pageSize;//每页记录数 固定值
	
	public PageBean(){}
	
	public PageBean(int pageCode, int totalRecord){
		this.pageCode = pageCode;
		this.totalRecord = totalRecord;
		this.pageSize = 6;//每页显示6条
	}
	
	public int getPageCode() {
		return pageCode;
	}
	public void setPageCode(int pageCode) {
		this.pageCode = pageCode;
	}
	
	public int getTotalPage() {
		int totalPage = this.totalRecord /this.pageSize;
		return this.totalRecord % this.pageSize == 0 ? totalPage : totalPage + 1;
	}
	
//	
//	public void setTotalPage(int totalPage) {
//		this.totalPage = totalPage;
//	}
	
	public List<Product> getDatas() {
		return datas;
	}
	public void setDatas(List<Product> datas) {
		this.datas = datas;
	}
	public int getTotalRecord() {
		return totalRecord;
	}
	public void setTotalRecord(int totalRecord) {
		this.totalRecord = totalRecord;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	
	
}
