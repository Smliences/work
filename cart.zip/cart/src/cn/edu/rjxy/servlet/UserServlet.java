package cn.edu.rjxy.servlet;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.edu.rjxy.bean.Admin;
import cn.edu.rjxy.bean.User;
import cn.edu.rjxy.service.AdminService;
import cn.edu.rjxy.service.UserException;
import cn.edu.rjxy.service.UserService;
import cn.edu.rjxy.utils.CommonsUtils;

public class UserServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private UserService userService = new UserService();
	private AdminService adminService = new AdminService();
	

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);

	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int method = Integer.parseInt(request.getParameter("method"));
		switch (method) {
			case 1:
				this.login(request, response);
				break;
			case 2:
				this.register(request, response);
				break;
			case 3:this.loginAgain(request, response);
				break;
			case 4:this.update(request, response);
				break;
			case 5:this.load(request, response);
				break;
			case 6:this.adminLoginAgain(request, response);
			break;
			
				

		}
	}
	
	/*客户登陆 method=1*/
	public void login(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String username = request.getParameter("username");
		String password = request.getParameter("password");

		User user = userService.findByUsername(username);
		if (user == null) {
			request.setAttribute("msg", "用户不存在");
			request.getRequestDispatcher("/login.jsp").forward(request,
					response);
		} else {
			if (password.equals(user.getPassword())) {
				/*登陆成功,把信息存入session*/
				request.getSession().setAttribute("user", user);
				request.getRequestDispatcher("/index.jsp").forward(request,
						response);
			} else {
				request.setAttribute("msg", "密码错误");
				request.getRequestDispatcher("/login.jsp").forward(request,
						response);
			}
		}

	}
	
	
	/*客户注册 method=2*/
	public void register(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		User user = CommonsUtils.toBean(request.getParameterMap(), User.class);
		user.setId(CommonsUtils.uuid());
		try {
			userService.register(user);
			request.setAttribute("msg", "注册成功，请登录");
			request.getRequestDispatcher("/login.jsp").forward(request, response);
		} catch (UserException e) {
			
			request.setAttribute("msg", e.getMessage());
			
			/*把信息存储在request域中，回显到register.jsp*/
			request.setAttribute("user", user);
			request.getRequestDispatcher("/userRegister.jsp").forward(request, response);
		}
		
	}

	
	/*客户注销登录 method=3*/
	public void loginAgain(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		/*注销登录*/
		request.getSession().invalidate();
		response.sendRedirect("/cart/");
		
	}
	
	/*客户修改信息，并把修改后的信息返回页面 method=4*/
	public void update(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		User user = CommonsUtils.toBean(request.getParameterMap(), User.class);
		String id =  user.getId();
		userService.update(user);
		userService.flashById(id);
		
		/*给出提示，把修改后的信息回显到修改页面*/
		request.getSession().setAttribute("user", user);
		request.setAttribute("msg", "修改成功");
		request.getRequestDispatcher("jsp/userInformation.jsp").forward(request, response);
		
	}
	
	/*管理员登录 	method=5*/
	public void load(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Admin admin = CommonsUtils.toBean(request.getParameterMap(),
				Admin.class);
		try {
			Admin ad = adminService.login(admin);
			//登陆成功，获取session,转发到adminIndex.jsp
			request.getSession().setAttribute("admin", ad);
			request.getRequestDispatcher("/adminIndex.jsp").forward(request, response);
			
		} catch (UserException e) {
			request.setAttribute("msg", e.getMessage());
			request.getRequestDispatcher("/AdminLogin.jsp").forward(request, response);
		}
	}
	
	/*管理员注销登录 method=6*/
	public void adminLoginAgain(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		/*注销登录*/
		request.getSession().invalidate();
		response.sendRedirect("/cart/");
		
	}
	
	
}
