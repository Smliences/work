package cn.edu.rjxy.servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cn.edu.rjxy.bean.PageBean;
import cn.edu.rjxy.bean.Product;
import cn.edu.rjxy.service.ProductService;
import cn.edu.rjxy.utils.CommonsUtils;

public class ProductServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ProductService ps = new ProductService();

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);

	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		int method = Integer.parseInt(request.getParameter("method"));
		switch (method) {
		case 1:
			this.findAllProduct(request, response);
			break;
		case 2:
			this.addCart(request, response);
			break;
		case 3:
			this.changeCart(request, response);
			break;
		case 4:
			this.deleteProduct(request, response);
			break;
		case 5:
			this.findById(request, response);
			break;
		case 6:
			this.adminFindAllProduct(request, response);
			break;
		case 7:
			this.update(request, response);
			break;
		case 8:
			this.queryPage(request, response);
			break;
		
		case 10:
			this.userQueryPage(request, response);
			break;
		case 11:
			this.findByCategory(request, response);
			break;
		}

	}

	/* 	用户操作	客户查询所有商品 method=1 */
	public void findAllProduct(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		List<Product> list = ps.findAll();
		request.setAttribute("p", list);
		request.getRequestDispatcher("prductShow.jsp")
				.forward(request, response);

	}

	/* 	用户操作	商品添加购物车 method=2 */
	public void addCart(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String id = request.getParameter("id");
		// 获取商品属性
		Product product = ps.findById(id);
		// 把属性存放到session中
		HttpSession session = request.getSession();
		// 从session中拿到购物车
		Map<Product, Integer> cart = (Map<Product, Integer>) session
				.getAttribute("cart");
		// 如果cart不存在，创建购物车
		if (cart == null) {
			cart = new HashMap<Product, Integer>();
		}

		/*
		 * 遍历map中所有的key，即商品对象， 如果发现有商品的id和即将加入购物车的id相同， 就在已有的商品原来数量基础上加1
		 */
		Iterator<Product> it = cart.keySet().iterator();
		boolean f = true;
		while (it.hasNext()) {
			Product pp = (Product) it.next();
			if (pp.getId().equals(product.getId())) {
				cart.put(pp, cart.get(pp) + 1);
				f = false;
			}
		}

		// 如果没有发现购物车原来有相同的商品，直接加入
		if (f) {
			cart.put(product, 1);
		}

		// 把cart放入session中
		session.setAttribute("cart", cart);
		response.sendRedirect("/cart/cart.jsp");
	}

	/* 	用户操作 	  修改购物车内的商品数量 method=3 */
	public void changeCart(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		String id = request.getParameter("id");
		int count = Integer.parseInt(request.getParameter("count"));
		HttpSession session = request.getSession();
		Map<Product, Integer> cart = (Map<Product, Integer>) session
				.getAttribute("cart");

		Iterator<Product> it = cart.keySet().iterator();
		while (it.hasNext()) {
			Product pp = (Product) it.next();
			if (pp.getId().equals(id)) {
				if (count == 0) {
					it.remove();
				} else {
					cart.put(pp, count);
				}
			}
		}

		response.sendRedirect("/cart/cart.jsp");
	}

	/* 管理员查询所有商品 method=6 */
	public void adminFindAllProduct(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		List<Product> list = ps.findAll();
		request.setAttribute("p", list);
		request.getRequestDispatcher("/adminIndex.jsp").forward(request,
				response);

	}

	/* 删除商品 管理员操作 method=4 */
	public void deleteProduct(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// 获取商品id
		String id = request.getParameter("id");
		// 调用ProductService中的方法
		ps.deleteProduct(id);
		List<Product> list = ps.findAll();
		request.setAttribute("productList", list);
		request.getRequestDispatcher("/adminIndex.jsp").forward(request,
				response);
	}

	/* 修改商品信息 管理员操作 method=5 */
	public void findById(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		Product p = ps.findById(id);

		request.setAttribute("p", p);

		request.getRequestDispatcher("/productEdit.jsp").forward(request,
				response);

	}

	/* 修改商品信息          method=7 */
	public void update(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Product p = CommonsUtils.toBean(request.getParameterMap(),
				Product.class);
		ps.updateProduct(p);
		/*修改后重新查询所有商品信息， 返回到adminIndex.jsp*/
		List<Product> list = ps.findAll();
		request.setAttribute("productList", list);
		request.getRequestDispatcher("/adminIndex.jsp").forward(request,
				response);
		
		
	}

	/* 管理员分页查询 	method=8 */
	public void queryPage(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		//当前页有一个默认值为1
		int pageCode = 1;
		String s = request.getParameter("pageCode");
		//如果请求中存在pageCode参数
		if(s != null && !s.trim().isEmpty()){
			pageCode = Integer.parseInt(s);
		}
		//查询当前页的记录
		PageBean pb = ps.queryByPage(pageCode);
		//将pb保存在request域中
		request.setAttribute("pb", pb);
		//通过请求转发将pb带到list.jsp上去
		request.getRequestDispatcher("adminIndex.jsp").forward(request, response);
		
	}
	/* 客户分页查询 method=10 */
	public void userQueryPage(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		//当前页有一个默认值为1
		int pageCode = 1;
		String s = request.getParameter("pageCode");
		//如果请求中存在pageCode参数
		if(s != null && !s.trim().isEmpty()){
			pageCode = Integer.parseInt(s);
		}
		//查询当前页的记录
		PageBean pb = ps.queryByPage(pageCode);
		//将pb保存在request域中
		request.setAttribute("pb", pb);
		//通过请求转发将pb带到list.jsp上去
		request.getRequestDispatcher("productShow.jsp").forward(request, response);
		
	}
	
	
	
	/* method=11  用户  根据种类查询*/
	public void findByCategory(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		//传入种类参数
		String category = request.getParameter("category");
		//
		request.setAttribute("cate", category);
		
		//当前页有一个默认值为1
		int pageCode = 1;
		String s = request.getParameter("pageCode");
		//如果请求中存在pageCode参数
		if(s != null && !s.trim().isEmpty()){
			pageCode = Integer.parseInt(s);
		}
		//查询当前页的记录
		PageBean pb = ps.queryByCategory(pageCode, category);
		//将pb保存在request域中
		request.setAttribute("pb", pb);
		//通过请求转发将pb带到上去
		request.getRequestDispatcher("categoryProductShow.jsp").forward(request, response);
		

	}
}
