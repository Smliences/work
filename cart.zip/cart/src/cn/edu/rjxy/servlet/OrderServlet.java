package cn.edu.rjxy.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.edu.rjxy.bean.Order;
import cn.edu.rjxy.bean.OrderItem;
import cn.edu.rjxy.bean.Product;
import cn.edu.rjxy.bean.User;
import cn.edu.rjxy.service.OrderService;
import cn.edu.rjxy.service.ProductService;
import cn.edu.rjxy.utils.CommonsUtils;

public class OrderServlet extends HttpServlet {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private OrderService orderService = new OrderService();
	ProductService ps=new ProductService();
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
		
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		int method = Integer.parseInt(request.getParameter("method"));
		switch (method) {
			case 1:this.addOrder(request, response);
					   	break;
			case 2:this.findMyOrder(request, response);
			   			break;
			case 3:this.findOrderItem(request, response);
			   			break;

		
		}
	}

	/*添加订单*/
	public void addOrder(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
		/*
		 * 1.判断用户是否登录，若未登录，重定向到登陆页面
		 * 2.实用工具类把订单表单中信息封装为Order对象，补全剩余字段
		 * 3.从session中获取购物车，遍历购物车，创建订单项
		 *		加入List集合
		 * 4.添加订单和订单项
		 * 
		 * */
		User user = (User)request.getSession().getAttribute("user");
		if(user == null){
			response.sendRedirect("/cart/login.jsp");
			return;
		}
		
		Order order = CommonsUtils.toBean(request.getParameterMap(), Order.class);
		order.setId(CommonsUtils.uuid());
		order.setOrdertime(new Date());
		order.setUser_id(user.getId());
		
		Map<Product,Integer> cart = 
			(Map<Product, Integer>) request.getSession().getAttribute("cart");
		List<OrderItem> list = new ArrayList<OrderItem>();
		for(Product p:cart.keySet()){
			OrderItem orderItem = new OrderItem();
			orderItem.setId(CommonsUtils.uuid());
			orderItem.setOrder_id(order.getId());
			orderItem.setProduct_id(p.getId());
			orderItem.setBuynum(cart.get(p));
			orderItem.setSubtotal(p.getPrice()*orderItem.getBuynum());
			//订单项加入list集合
			list.add(orderItem);
		}
		order.setList(list);
		//添加订单和订单项
		String result = orderService.addOrder(order);
		request.setAttribute("orderResult", result);
		request.getRequestDispatcher("/jsp/result.jsp").forward(request, response);
		
		
		
	}
	
	/*查看我的订单   method=2*/
	public void findMyOrder(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
		/*
		 * 1.从session中获取用户信息，得到用户id
		 * 2.执行查询我的订单
		 * 3.把查询结果转发到myOrder.jsp
		 * 
		 * */
		
		User user = (User) request.getSession().getAttribute("user");
		if(user == null){
			request.getRequestDispatcher("/cart/login.jsp").forward(request, response);	
		}
		List<Order> list = orderService.findMyOrder(user.getId());
		request.setAttribute("myOrderList", list);
		request.getRequestDispatcher("/jsp/myOrder.jsp").forward(request, response);
	}
	
	/*查看订单详情*/
	public void findOrderItem(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
		/*
		 * 1.从请求中获取order_id
		 * 2.通过方法获取订单所有订单项集合
		 * 3.通过请求转发到orderItem.jsp
		 * */
		String order_id = request.getParameter("order_id");
		List<OrderItem> L= orderService.findOrderItem(order_id);
		for(int i=0;i<L.size();i++){
		L.get(i).setProduct(ps.findById(L.get(i).getProduct_id()));
		
		}
		request.setAttribute("orderItemList",L);
		request.getRequestDispatcher("/jsp/orderItem.jsp").forward(request, response);
		
	}
	
	
	
	
}





