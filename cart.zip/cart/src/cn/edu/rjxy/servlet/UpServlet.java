﻿package cn.edu.rjxy.servlet;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadBase;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;



import cn.edu.rjxy.bean.Product;
import cn.edu.rjxy.service.ProductService;
import cn.edu.rjxy.utils.CommonsUtils;

public class UpServlet extends HttpServlet {
Product p=new Product();
ProductService ps = new ProductService();
	int index=0;
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
this.doPost(request, response);
		
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		p.setId(CommonsUtils.uuid());
		DiskFileItemFactory factory = new DiskFileItemFactory();
		//使用工厂对象作为参数创建一个ServletFileUplaod对象
		ServletFileUpload fileUpload = new ServletFileUpload(factory);
		//解决文件名中文乱码
		fileUpload.setHeaderEncoding("UTF-8");
		//设置上传的单个文件的大小上限：1024KB=1MB
		fileUpload.setFileSizeMax(1024*1024);
		try {
			//使用fileUpload对象解析request请求体中的内容，得到FileItem链表
			List<FileItem> list = fileUpload.parseRequest(request);
			//遍历list得到每一个FileItem（也就是每一个表单项）
			for(FileItem fileItem:list){
				//如果当前表单项为普通文本字段
				if(fileItem.isFormField()){//普通文本字段
					//获取表单项的字段名称
					String fieldName = fileItem.getFieldName();
					if(fieldName.equals("name")){
						//输出字段值,采用UTF-8字符集得到字段值，保证不会出现中文乱码
						p.setName(fileItem.getString("UTF-8"));
					}
					if(fieldName.equals("price")){
						//输出字段值,采用UTF-8字符集得到字段值，保证不会出现中文乱码
						String price1=(fileItem.getString("UTF-8"));
						double price=Double.parseDouble(price1);
						p.setPrice(price);
					}
					if(fieldName.equals("pnum")){
						int pnum= Integer.parseInt(fileItem.getString("UTF-8"));
						p.setPnum(pnum);
					}
					if(fieldName.equals("description")){
						
						p.setDescription(fileItem.getString("UTF-8"));
					}
					if(fieldName.equals("category")){
						
						p.setCategory(fileItem.getString("UTF-8"));
					}
				}else{//上传文件字段
					index++;
					//获取文件名
					String name = fileItem.getName();
					//如果名字为空，就是没有指定上传文件
					if(name==null || name.isEmpty()){
						continue;
					}
					//获取真实的文件路径，其实就是服务器上的一个目录，这个目录必须存在
					String savepath = "D:/pic";
					//为了保证上传的文件名是唯一的，可以使用UUID
					String uuid = CommonsUtils.uuid().toString();
					//重新构建的文件名为：uuid_原始文件名
					String filename = uuid+"_"+name;
					
				
					
					//通过文件上传路径和文件名创建File对象
					File file = new File(savepath, filename);
					//将内容写到文件中去,上传完成
					fileItem.write(file);
					if(index==1){
						p.setImgurl(filename);
					}
					if(index==2){
						p.setImgurl2(filename);
					}
					
				}
			}
			ps.addProduct(p);
			request.getRequestDispatcher("/adminIndex.jsp").forward(request, response);
		} catch (Exception e) {
			//判断异常的类型
			if(e instanceof FileUploadBase.FileSizeLimitExceededException){
				//将错误信息存放到request域中
				request.setAttribute("msg", "上传失败，文件大小超过1MB");
				//请求转发到upload.jsp
				request.getRequestDispatcher("/addProduct.jsp").forward(request, response);
				return;
			}
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		
	}

		
	}


