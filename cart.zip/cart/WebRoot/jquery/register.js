//鼠标放到文本框
function unFocus(){
	 var checkUn = document.getElementById("unId");
	checkUn.innerHTML = "由3到16位简体汉字数字字母组成，注册后不能修改";
	
}

//鼠标离开文本框
function unBlur(){
	var un = document.getElementById("un");
	var unId = document.getElementById("unId");
	//简体中文或大小写英文或数字，3到16位
	var reg = /^[\u4E00-\u9FA5A-Za-z0-9]{3,16}$/;
	if(un.value == ""){
		unId.innerHTML = "<font color='red'>用户名不能为空</font>";
		return false;
	}
	if(reg.test(un.value)== false){
		unId.innerHTML = "<font color='red'>简体汉字数字字母组成</font>";
		return false;
	}
	unId.innerHTML = "<font color='green'>用户名输入正确</font>";
	return true;
}

function psFocus(){
	 var checkPs = document.getElementById("psId");
	checkPs.innerHTML = "由3到16位数字和字母组成";
	
}
function psBlur(){
	var ps = document.getElementById("ps");
	var psId = document.getElementById("psId");
	var reg = /^[A-Za-z0-9]{3,16}$/;
	if(ps.value == ""){
		psId.innerHTML = "<font color='red'>密码不能为空</font>";
		return false;
	}
	if(reg.test(ps.value)== false){
		psId.innerHTML = "<font color='red'>数字和字母组成</font>";
		return false;
	}
	
	psId.innerHTML = "<font color='green'>密码格式正确</font>";
	return true;
}
function repsFocus(){
	 var checkPs = document.getElementById("repsId");
	checkPs.innerHTML = "请于上面的密码一致";
	
}

function repsBlur(){
	var ps = document.getElementById("ps");
	var reps = document.getElementById("reps");
	var repsId = document.getElementById("repsId");
	
	if(reps.value==ps.value){
		repsId.innerHTML = "<font color='green'>两次密码输入一致</font>";	
		return true;
	}
	
	repsId.innerHTML = "<font color='red'>两次输入密码不一致</font>";
	return false;
}

function rnFocus(){
	var checkRn = document.getElementById("rnId");
	checkRn.innerHTML = "由2到18位简体汉字组成";
	
}

function rnBlur(){
	var rn = document.getElementById("rn");
	var rnId = document.getElementById("rnId");
	var reg = /^[\u4e00-\u9fa5]{2,18}$/;
	if(rn.value == ""){
		rnId.innerHTML = "<font color='red'>姓名不能为空</font>";
		return false;
	}
	if(reg.test(rn.value)== false){
		rnId.innerHTML = "<font color='red'>请输入简体中文</font>";
		return false;
	}
	rnId.innerHTML = "<font color='green'>姓名格式正确</font>";
	return true;
}

function phoneFocus(){
	var checkPhone = document.getElementById("phoneId");
	checkPhone.innerHTML = "请输入11位真实手机号";
	
}
function phoneBlur(){
	var phone = document.getElementById("phone");
	var phoneId = document.getElementById("phoneId");
	var reg =/^(13[0-9]|14[5|7]|15[0|1|2|3|5|6|7|8|9]|17[0-8]|18[0|1|2|3|5|6|7|8|9])\d{8}$/;
	
	if(phone.value == ""){
		phoneId.innerHTML = "<font color='red'>电话号码不能为空</font>";
		return false;
	}
	if(reg.test(phone.value)== false){
		phoneId.innerHTML = "<font color='red'>输入有效的11位手机号码</font>";
		return false;
	}
	phoneId.innerHTML = "<font color='green'>手机格式正确</font>";
	return true;
}


//表单提交检验各个字段是是否合法
function checkForm() {
	var flagUn = unBlur();
	var flagPs = psBlur();
	var flagrePs = repsBlur();
	var flagPhone = phoneBlur();
	var flagRn = rnBlur();
	
	if(flagUn == true && flagPs == true && flagPhone == true && flagRn == true && flagrePs == true){
		return true;
	}else{
		return false;
	}
}




